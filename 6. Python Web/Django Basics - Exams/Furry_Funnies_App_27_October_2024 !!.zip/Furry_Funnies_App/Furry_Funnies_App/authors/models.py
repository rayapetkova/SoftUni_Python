from django.core import validators
from django.core.exceptions import ValidationError
from django.db import models


def first_and_last_names_validator(value):
    if not value.isalpha():
        raise ValidationError("Your name must contain letters only!")

    return value


def passcode_validator(value):
    if not len(value) == 6 or not value.isdigit():
        raise ValidationError("Your passcode must be exactly 6 digits!")

    return value


class Author(models.Model):
    first_name = models.CharField(
        null=False,
        blank=False,
        max_length=40,
        validators=[
            validators.MinLengthValidator(4),
            first_and_last_names_validator
        ]
    )

    last_name = models.CharField(
        null=False,
        blank=False,
        max_length=50,
        validators=[
            validators.MinLengthValidator(2),
            first_and_last_names_validator
        ]
    )

    passcode = models.CharField(
        null=False,
        blank=False,
        validators=[
            passcode_validator
        ],
        help_text="Your passcode must be a combination of 6 digits"
    )

    pets_number = models.PositiveSmallIntegerField(
        null=False,
        blank=False
    )

    info = models.TextField(
        null=True,
        blank=True
    )

    image_url = models.URLField(
        null=True,
        blank=True
    )
