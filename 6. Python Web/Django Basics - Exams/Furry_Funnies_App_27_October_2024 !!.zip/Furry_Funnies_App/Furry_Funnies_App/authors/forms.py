from django import forms

from Furry_Funnies_App.authors.models import Author


class AuthorBaseForm(forms.ModelForm):

    class Meta:
        model = Author
        fields = '__all__'


class AuthorCreateForm(AuthorBaseForm):

    class Meta:
        model = Author
        fields = ('first_name', 'last_name', 'passcode', 'pets_number')

        widgets = {
            'passcode': forms.PasswordInput()
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        self.fields['first_name'].widget.attrs['placeholder'] = "Enter your first name..."
        self.fields['first_name'].label = "First Name:"

        self.fields['last_name'].widget.attrs['placeholder'] = "Enter your last name..."
        self.fields['last_name'].label = "Last Name:"

        self.fields['passcode'].widget.attrs['placeholder'] = "Enter 6 digits..."
        self.fields['passcode'].label = "Passcode:"

        self.fields['pets_number'].widget.attrs['placeholder'] = "Enter the number of your pets..."
        self.fields['pets_number'].label = "Pets Number:"


class AuthorEditForm(AuthorBaseForm):

    class Meta:
        model = Author
        exclude = ('passcode', )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        self.fields['first_name'].label = "First Name:"
        self.fields['last_name'].label = "Last Name:"
        self.fields['pets_number'].label = "Pets Number:"
        self.fields['image_url'].label = "Profile Image URL:"
