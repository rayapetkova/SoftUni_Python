from django.urls import path

from Furry_Funnies_App.authors.views import CreateAuthorView, DetailsAuthorView, UpdateAuthorView, DeleteAuthorView

urlpatterns = [
    path('create/', CreateAuthorView.as_view(), name='create-author'),
    path('details/', DetailsAuthorView.as_view(), name='details-author'),
    path('edit/', UpdateAuthorView.as_view(), name='edit-author'),
    path('delete/', DeleteAuthorView.as_view(), name='delete-author')
]
