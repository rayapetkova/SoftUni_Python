from django.shortcuts import render
from django.urls import reverse_lazy
from django.views.generic import CreateView, DetailView, UpdateView, DeleteView

from Furry_Funnies_App.authors.forms import AuthorCreateForm, AuthorEditForm
from Furry_Funnies_App.authors.models import Author


class CreateAuthorView(CreateView):
    model = Author
    form_class = AuthorCreateForm
    template_name = 'create-author.html'
    success_url = reverse_lazy('dashboard')

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)

        author = Author.objects.all().first()
        context['author'] = author

        return context


class DetailsAuthorView(DetailView):
    model = Author
    template_name = 'details-author.html'

    def get_object(self, queryset=None):
        author = Author.objects.all().first()
        return author

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)

        author_last_updated_post = self.object.posts.filter(author=self.object).order_by('-updated_at').first()
        context['author_last_updated_post'] = author_last_updated_post

        return context


class UpdateAuthorView(UpdateView):
    model = Author
    form_class = AuthorEditForm
    template_name = 'edit-author.html'
    success_url = reverse_lazy('details-author')

    def get_object(self, queryset=None):
        author = Author.objects.all().first()
        return author


class DeleteAuthorView(DeleteView):
    model = Author
    success_url = reverse_lazy('index-page')
    template_name = 'delete-author.html'

    def get_object(self, queryset=None):
        author = Author.objects.all().first()
        return author
