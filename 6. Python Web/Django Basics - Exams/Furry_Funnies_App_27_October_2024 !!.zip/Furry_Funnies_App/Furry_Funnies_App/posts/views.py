from django.shortcuts import render, redirect
from django.urls import reverse_lazy
from django.views.generic import CreateView, DetailView, UpdateView, DeleteView

from Furry_Funnies_App.authors.models import Author
from Furry_Funnies_App.posts.forms import PostCreateForm, PostEditForm, DeletePostForm
from Furry_Funnies_App.posts.models import Post


class CreatePostView(CreateView):
    model = Post
    form_class = PostCreateForm
    template_name = 'create-post.html'
    success_url = reverse_lazy('dashboard')

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)

        author = Author.objects.all().first()
        context['author'] = author

        return context


class DetailsPostView(DetailView):
    model = Post
    pk_url_kwarg = 'post_id'
    template_name = 'details-post.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)

        author = Author.objects.all().first()
        context['author'] = author

        return context


class UpdatePostView(UpdateView):
    model = Post
    form_class = PostEditForm
    pk_url_kwarg = 'post_id'
    template_name = 'edit-post.html'
    success_url = reverse_lazy('dashboard')

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)

        author = Author.objects.all().first()
        context['author'] = author

        return context


def delete_post_view(request, post_id):
    post = Post.objects.filter(id=post_id).first()
    author = Author.objects.all().first()
    form = DeletePostForm(instance=post)

    if request.method == "POST":
        post.delete()
        return redirect('dashboard')

    context = {
        'author': author,
        'form': form
    }

    return render(request, 'delete-post.html', context=context)

