from django.urls import path

from Furry_Funnies_App.posts.views import CreatePostView, DetailsPostView, UpdatePostView, delete_post_view

urlpatterns = [
    path('create/', CreatePostView.as_view(), name='create-post'),
    path('<int:post_id>/details/', DetailsPostView.as_view(), name='details-post'),
    path('<int:post_id>/edit/', UpdatePostView.as_view(), name='edit-post'),
    path('<int:post_id>/delete/', delete_post_view, name='delete-post')
]
