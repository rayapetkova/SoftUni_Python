from django import forms

from Furry_Funnies_App.authors.models import Author
from Furry_Funnies_App.posts.models import Post


class PostBaseForm(forms.ModelForm):

    class Meta:
        model = Post
        exclude = ('updated_at', 'author')


class PostCreateForm(PostBaseForm):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        self.fields['title'].widget.attrs['placeholder'] = "Put an attractive and unique title..."
        self.fields['title'].label = "Title:"

        self.fields['image_url'].label = "Post Image URL:"

        self.fields['content'].widget.attrs['placeholder'] = "Share some interesting facts about your adorable pets..."
        self.fields['content'].label = "Content:"

    def save(self, commit=True):
        post = super().save(commit=False)

        author = Author.objects.all().first()
        post.author = author

        if commit:
            post.save()

        return post


class PostEditForm(PostBaseForm):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        self.fields['image_url'].label = "Post Image URL:"


class DeletePostForm(PostBaseForm):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        self.fields['image_url'].label = "Post Image URL:"

        for field in self.fields:
            self.fields[field].widget.attrs['readonly'] = 'readonly'
            self.fields[field].help_text = None
