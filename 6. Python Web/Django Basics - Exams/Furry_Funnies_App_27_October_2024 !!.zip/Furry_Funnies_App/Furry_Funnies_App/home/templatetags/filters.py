from django import template


register = template.Library()


@register.filter(name='first_three_words')
def first_three_words(value):
    value_list = value.split()

    return ' '.join(value_list[:3])
