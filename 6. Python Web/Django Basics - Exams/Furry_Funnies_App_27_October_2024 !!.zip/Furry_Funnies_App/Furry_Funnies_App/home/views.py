from django.shortcuts import render

from Furry_Funnies_App.authors.models import Author
from Furry_Funnies_App.posts.models import Post


def index_page_view(request):
    author = Author.objects.all().first()

    context = {
        'author': author
    }

    return render(request, 'index.html', context=context)


def dashboard_page_view(request):
    posts = Post.objects.all()
    author = Author.objects.all().first()

    context = {
        'posts': posts,
        'author': author
    }

    return render(request, 'dashboard.html', context=context)
