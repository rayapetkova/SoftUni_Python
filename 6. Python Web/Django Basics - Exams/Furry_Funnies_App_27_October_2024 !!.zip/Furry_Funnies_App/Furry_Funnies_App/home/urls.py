from django.urls import path

from Furry_Funnies_App.home.views import index_page_view, dashboard_page_view

urlpatterns = [
    path('', index_page_view, name='index-page'),
    path('dashboard/', dashboard_page_view, name='dashboard')
]
