from django.shortcuts import render

from World_of_Speed_App.app_users.models import Profile


def index_page(request):
    user = Profile.objects.all().first()

    context = {
        'user': user
    }

    return render(request, 'index.html', context=context)