from django.urls import path

from World_of_Speed_App.home.views import index_page

urlpatterns = [
    path('', index_page, name='index-page')
]