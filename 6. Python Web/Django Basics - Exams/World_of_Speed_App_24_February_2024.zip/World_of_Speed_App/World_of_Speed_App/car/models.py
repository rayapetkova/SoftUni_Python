from django.core import validators
from django.core.exceptions import ValidationError
from django.db import models

from World_of_Speed_App.app_users.models import Profile


def year_validator(value):
    if not 1999 <= value <= 2030:
        raise ValidationError("Year must be between 1999 and 2030!")

    return value


class Car(models.Model):
    TYPE_CHOICES = (
        ('Rally', 'Rally'),
        ('Open-wheel', 'Open-wheel'),
        ('Kart', 'Kart'),
        ('Drag', 'Drag'),
        ('Other', 'Other')
    )

    type = models.CharField(
        null=False,
        blank=False,
        max_length=10,
        choices=TYPE_CHOICES
    )

    model = models.CharField(
        null=False,
        blank=False,
        max_length=15,
        validators=[
            validators.MinLengthValidator(1)
        ]
    )

    year = models.IntegerField(
        null=False,
        blank=False,
        validators=[
            year_validator
        ]
    )

    image_url = models.URLField(
        null=False,
        blank=False,
        unique=True,
        error_messages={
            'unique': "This image URL is already in use! Provide a new one."
        }
    )

    price = models.FloatField(
        null=False,
        blank=False,
        validators=[
            validators.MinValueValidator(1.0)
        ]
    )

    owner = models.ForeignKey(
        to=Profile,
        on_delete=models.CASCADE
    )
