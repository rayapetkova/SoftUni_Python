from django.shortcuts import render, redirect
from django.urls import reverse_lazy
from django.views.generic import CreateView, ListView, DetailView, UpdateView

from World_of_Speed_App.app_users.models import Profile
from World_of_Speed_App.car.forms import CarCreateForm, CarEditForm, CarDeleteForm
from World_of_Speed_App.car.models import Car


class CreateCarView(CreateView):
    model = Car
    form_class = CarCreateForm
    template_name = 'car-create.html'
    success_url = reverse_lazy('catalogue')

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)

        user = Profile.objects.all().first()
        context['user'] = user

        return context


class CatalogueListView(ListView):
    model = Car
    template_name = 'catalogue.html'

    def get_context_data(self, *, object_list=None, **kwargs):
        context = super().get_context_data(**kwargs)

        user = Profile.objects.all().first()
        context['user'] = user

        return context


class DetailsCarView(DetailView):
    model = Car
    template_name = 'car-details.html'
    pk_url_kwarg = 'id'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)

        user = Profile.objects.all().first()
        context['user'] = user

        return context


class UpdateCarView(UpdateView):
    model = Car
    form_class = CarEditForm
    template_name = 'car-edit.html'
    pk_url_kwarg = 'id'
    success_url = reverse_lazy('catalogue')

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)

        user = Profile.objects.all().first()
        context['user'] = user

        return context


def delete_car_view(request, id):
    car = Car.objects.all().filter(id=id).first()
    form = CarDeleteForm(instance=car)
    user = Profile.objects.all().first()

    if request.method == "POST":
        car.delete()

        return redirect('catalogue')

    context = {
        'form': form,
        'user': user
    }

    return render(request, 'car-delete.html', context=context)
