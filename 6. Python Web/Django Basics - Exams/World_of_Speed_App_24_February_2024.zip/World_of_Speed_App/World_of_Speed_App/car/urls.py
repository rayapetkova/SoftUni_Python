from django.urls import path

from World_of_Speed_App.car.views import CreateCarView, CatalogueListView, DetailsCarView, UpdateCarView, \
    delete_car_view

urlpatterns = [
    path('create/', CreateCarView.as_view(), name='create-car'),
    path('catalogue/', CatalogueListView.as_view(), name='catalogue'),
    path('<int:id>/details/', DetailsCarView.as_view(), name='details-car'),
    path('<int:id>/edit/', UpdateCarView.as_view(), name='edit-car'),
    path('<int:id>/delete/', delete_car_view, name='delete-car')
]
