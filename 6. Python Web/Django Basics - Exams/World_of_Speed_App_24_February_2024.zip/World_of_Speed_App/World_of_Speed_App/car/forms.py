from django import forms

from World_of_Speed_App.app_users.models import Profile
from World_of_Speed_App.car.models import Car


class CarCreateForm(forms.ModelForm):

    class Meta:
        model = Car
        exclude = ('owner', )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['image_url'].widget.attrs['placeholder'] = "https://..."

    def save(self, commit=True):
        car = super().save(commit=False)

        user = Profile.objects.all().first()
        car.owner = user

        if commit:
            car.save()

        return car


class CarEditForm(forms.ModelForm):

    class Meta:
        model = Car
        exclude = ('owner', )


class CarDeleteForm(forms.ModelForm):

    class Meta:
        model = Car
        exclude = ('owner', )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        for field in self.fields:
            self.fields[field].widget.attrs['readonly'] = 'readonly'
