from django.db.models import Sum
from django.shortcuts import render, redirect
from django.urls import reverse_lazy
from django.views.generic import CreateView, DetailView, UpdateView

from World_of_Speed_App.app_users.forms import ProfileCreateForm, ProfileUpdateForm
from World_of_Speed_App.app_users.models import Profile
from World_of_Speed_App.car.models import Car


class CreateProfileView(CreateView):
    model = Profile
    form_class = ProfileCreateForm
    template_name = 'profile-create.html'
    success_url = reverse_lazy('catalogue')


class DetailsProfileView(DetailView):
    model = Profile
    template_name = 'profile-details.html'

    def get_object(self, queryset=None):
        user = Profile.objects.all().first()

        return user

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)

        user_cars_sum_price = Car.objects.filter(owner=self.object).aggregate(total_price=Sum('price'))
        context['user_cars_sum_price'] = user_cars_sum_price

        return context


class UpdateProfileView(UpdateView):
    model = Profile
    form_class = ProfileUpdateForm
    template_name = 'profile-edit.html'
    success_url = reverse_lazy('details-profile')

    def get_object(self, queryset=None):
        user = Profile.objects.all().first()

        return user

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)

        user = Profile.objects.all().first()
        context['user'] = user

        return context


def delete_profile_view(request):
    user = Profile.objects.all().first()

    if request.method == "POST":
        user.delete()
        return redirect('index-page')

    context = {
        'user': user
    }

    return render(request, 'profile-delete.html', context=context)
