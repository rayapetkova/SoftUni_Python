import re

from django.core import validators
from django.core.exceptions import ValidationError
from django.db import models


def username_validator(value):
    if not re.match(r'^\w*$', value):
        raise ValidationError("Username must contain only letters, digits, and underscores!")

    return value


class Profile(models.Model):
    username = models.CharField(
        null=False,
        blank=False,
        max_length=15,
        validators=[
            validators.MinLengthValidator(3, "Username must be at least 3 chars long!"),
            username_validator
        ]
    )

    email = models.EmailField(
        null=False,
        blank=False
    )

    age = models.IntegerField(
        null=False,
        blank=False,
        validators=[
            validators.MinValueValidator(21)
        ],
        help_text="Age requirement: 21 years and above."
    )

    password = models.CharField(
        null=False,
        blank=False,
        max_length=20
    )

    first_name = models.CharField(
        null=True,
        blank=True,
        max_length=25
    )

    last_name = models.CharField(
        null=True,
        blank=True,
        max_length=25
    )

    profile_picture = models.URLField(
        null=True,
        blank=True
    )
