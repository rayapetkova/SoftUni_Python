from django import forms

from World_of_Speed_App.app_users.models import Profile


class ProfileCreateForm(forms.ModelForm):

    class Meta:
        model = Profile
        fields = ('username', 'email', 'age', 'password')

        widgets = {
            'password': forms.PasswordInput()
        }


class ProfileUpdateForm(forms.ModelForm):

    class Meta:
        model = Profile
        fields = '__all__'
