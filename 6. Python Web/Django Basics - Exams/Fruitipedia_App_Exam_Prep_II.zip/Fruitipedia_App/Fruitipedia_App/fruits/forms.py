from django.forms import ModelForm

from Fruitipedia_App.app_users.models import Profile
from Fruitipedia_App.fruits.models import Fruit


class FruitBaseForm(ModelForm):

    class Meta:
        model = Fruit
        exclude = ('owner', )


class FruitCreateForm(FruitBaseForm):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        self.fields['name'].widget.attrs['placeholder'] = 'Fruit Name'
        self.fields['name'].label = ''

        self.fields['image_URL'].widget.attrs['placeholder'] = 'Fruit Image URL'
        self.fields['image_URL'].label = ''

        self.fields['description'].widget.attrs['placeholder'] = 'Fruit Description'
        self.fields['description'].label = ''

        self.fields['nutrition'].widget.attrs['placeholder'] = 'Nutrition Info'
        self.fields['nutrition'].label = ''

    def save(self, commit=True):
        fruit = super().save(commit=False)

        owner = Profile.objects.all().first()
        fruit.owner = owner

        if commit:
            fruit.save()

        return fruit


class FruitEditForm(FruitBaseForm):

    class Meta:
        model = Fruit
        exclude = ('owner',)

        labels = {
            'name': 'Name:',
            'image_URL': 'Image URL:',
            'description': 'Description',
            'nutrition': 'Nutrition'
        }


class FruitDeleteForm(FruitBaseForm):

    class Meta:
        model = Fruit
        exclude = ('owner', 'nutrition')

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        self.fields['name'].widget.attrs['disabled'] = 'disabled'
        self.fields['name'].label = 'Name:'

        self.fields['image_URL'].widget.attrs['disabled'] = 'disabled'
        self.fields['image_URL'].label = 'Image URL'

        self.fields['description'].widget.attrs['disabled'] = 'disabled'
        self.fields['description'].label = 'Description:'
