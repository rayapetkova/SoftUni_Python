from django.core import validators
from django.core.exceptions import ValidationError
from django.db import models

from Fruitipedia_App.app_users.models import Profile


def fruit_name_validator(value):
    for symbol in value:
        if not symbol.isalpha():
            raise ValidationError("Fruit name should contain only letters!")

    return value


class Fruit(models.Model):
    name = models.CharField(
        null=False,
        blank=False,
        unique=True,
        max_length=30,
        validators=[
            validators.MinLengthValidator(2),
            fruit_name_validator
        ],
        error_messages={
            'unique': "This fruit name is already in use! Try a new one."
        }
    )

    image_URL = models.URLField(
        null=False,
        blank=False
    )

    description = models.TextField(
        null=False,
        blank=False
    )

    nutrition = models.TextField(
        null=True,
        blank=True
    )

    owner = models.ForeignKey(
        to=Profile,
        on_delete=models.CASCADE
    )
