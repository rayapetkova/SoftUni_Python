from django.urls import path

from Fruitipedia_App.fruits.views import index_page, DashboardListView, CreateFruitView, DetailsFruitView, \
    UpdateFruitView, delete_fruit_view

urlpatterns = [
    path('', index_page, name='index-page'),
    path('dashboard/', DashboardListView.as_view(), name='dashboard-page'),
    path('fruit/create/', CreateFruitView.as_view(), name='create-fruit'),
    path('fruit/<int:fruitId>/details/', DetailsFruitView.as_view(), name='details-fruit'),
    path('fruit/<int:fruitId>/edit/', UpdateFruitView.as_view(), name='edit-fruit'),
    path('fruit/<int:fruitId>/delete/', delete_fruit_view, name='delete-fruit')
]
