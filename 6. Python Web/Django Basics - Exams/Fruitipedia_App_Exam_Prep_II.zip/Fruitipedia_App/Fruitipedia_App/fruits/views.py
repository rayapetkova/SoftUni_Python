from django.shortcuts import render, redirect
from django.urls import reverse_lazy
from django.views.generic import ListView, CreateView, DetailView, UpdateView

from Fruitipedia_App.app_users.models import Profile
from Fruitipedia_App.fruits.forms import FruitCreateForm, FruitEditForm, FruitDeleteForm
from Fruitipedia_App.fruits.models import Fruit


def index_page(request):
    user = Profile.objects.all().first()

    context = {
        'user': user
    }
    return render(request, 'index.html', context=context)


class DashboardListView(ListView):
    model = Fruit
    template_name = 'dashboard.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)

        user = Profile.objects.all().first()
        context['user'] = user

        return context


class CreateFruitView(CreateView):
    model = Fruit
    form_class = FruitCreateForm
    template_name = 'create-fruit.html'
    success_url = reverse_lazy('dashboard-page')

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)

        user = Profile.objects.all().first()
        context['user'] = user

        return context


class DetailsFruitView(DetailView):
    model = Fruit
    pk_url_kwarg = 'fruitId'
    template_name = 'details-fruit.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)

        user = Profile.objects.all().first()
        context['user'] = user

        return context


class UpdateFruitView(UpdateView):
    model = Fruit
    form_class = FruitEditForm
    pk_url_kwarg = 'fruitId'
    template_name = 'edit-fruit.html'
    success_url = reverse_lazy('dashboard-page')

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)

        user = Profile.objects.all().first()
        context['user'] = user

        return context


def delete_fruit_view(request, fruitId):
    fruit = Fruit.objects.filter(id=fruitId).first()
    form = FruitDeleteForm(instance=fruit)
    user = Profile.objects.all().first()

    if request.method == "POST":
        fruit.delete()
        return redirect('dashboard-page')

    context = {
        'form': form,
        'user': user
    }
    return render(request, 'delete-fruit.html', context=context)
