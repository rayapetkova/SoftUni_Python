from django.core import validators
from django.core.exceptions import ValidationError
from django.db import models


def first_and_last_name_validator(value):
    if not value[0].isalpha():
        raise ValidationError('Your name must start with a letter!')

    return value


class Profile(models.Model):
    first_name = models.CharField(
        null=False,
        blank=False,
        max_length=25,
        validators=[
            validators.MinLengthValidator(2),
            first_and_last_name_validator
        ]
    )

    last_name = models.CharField(
        null=False,
        blank=False,
        max_length=35,
        validators=[
            validators.MinLengthValidator(1),
            first_and_last_name_validator
        ]
    )

    email = models.EmailField(
        null=False,
        blank=False,
        unique=True,
        max_length=40
    )

    password = models.CharField(
        null=False,
        blank=False,
        max_length=20,
        validators=[
            validators.MinLengthValidator(8)
        ],
        help_text="*Password length requirements: 8 to 20 characters"
    )

    image_URL = models.URLField(
        null=True,
        blank=True
    )

    age = models.IntegerField(
        null=True,
        blank=True,
        default=18
    )
