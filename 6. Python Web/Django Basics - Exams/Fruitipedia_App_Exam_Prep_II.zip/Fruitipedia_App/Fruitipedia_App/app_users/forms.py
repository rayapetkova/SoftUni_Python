from django.forms import ModelForm, PasswordInput

from Fruitipedia_App.app_users.models import Profile


class ProfileBaseForm(ModelForm):

    class Meta:
        model = Profile
        fields = '__all__'

        widgets = {
            'password': PasswordInput
        }


class ProfileCreateForm(ProfileBaseForm):

    class Meta:
        model = Profile
        exclude = ('image_URL', 'age')

        widgets = {
            'password': PasswordInput
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        self.fields['first_name'].widget.attrs['placeholder'] = 'First Name'
        self.fields['first_name'].label = ''

        self.fields['last_name'].widget.attrs['placeholder'] = 'Last Name'
        self.fields['last_name'].label = ''

        self.fields['email'].widget.attrs['placeholder'] = 'Email'
        self.fields['email'].label = ''

        self.fields['password'].widget.attrs['placeholder'] = 'Password'
        self.fields['password'].label = ''


class ProfileUpdateForm(ProfileBaseForm):

    class Meta:
        model = Profile
        exclude = ('email', 'password')

