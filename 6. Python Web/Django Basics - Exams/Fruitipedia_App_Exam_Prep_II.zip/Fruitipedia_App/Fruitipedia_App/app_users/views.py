from django.shortcuts import render, redirect
from django.urls import reverse_lazy
from django.views.generic import CreateView, DetailView, UpdateView

from Fruitipedia_App.app_users.forms import ProfileCreateForm, ProfileUpdateForm
from Fruitipedia_App.app_users.models import Profile


class CreateProfileView(CreateView):
    model = Profile
    form_class = ProfileCreateForm
    template_name = 'create-profile.html'
    success_url = reverse_lazy('dashboard-page')


class DetailsProfileView(DetailView):
    model = Profile
    template_name = 'details-profile.html'

    def get_object(self, queryset=None):
        user = Profile.objects.all().first()
        return user


class UpdateProfileView(UpdateView):
    model = Profile
    form_class = ProfileUpdateForm
    template_name = 'edit-profile.html'
    success_url = reverse_lazy('details-profile')

    def get_object(self, queryset=None):
        user = Profile.objects.all().first()
        return user


def delete_profile_view(request):
    user = Profile.objects.all().first()

    if request.method == 'POST':
        user.delete()
        return redirect('index-page')

    context = {
        'user': user
    }

    return render(request, 'delete-profile.html', context=context)
