from django.urls import path

from Fruitipedia_App.app_users.views import CreateProfileView, DetailsProfileView, UpdateProfileView, \
    delete_profile_view

urlpatterns = [
    path('create/', CreateProfileView.as_view(), name='create-profile'),
    path('details/', DetailsProfileView.as_view(), name='details-profile'),
    path('edit/', UpdateProfileView.as_view(), name='edit-profile'),
    path('delete/', delete_profile_view, name='delete-profile')
]
