import re

from django.core import validators
from django.core.exceptions import ValidationError
from django.db import models


def validate_username(value):
    if not re.match(r'^\w+$', value):
        raise ValidationError(message='Ensure this value contains only letters, numbers, and underscore.')

    return value


class Profile(models.Model):
    username = models.CharField(
        null=False,
        blank=False,
        max_length=15,
        validators=[
            validators.MinLengthValidator(2),
            validate_username
        ]
    )

    email = models.EmailField(
        null=False,
        blank=False
    )

    age = models.IntegerField(
        null=True,
        blank=True,
        validators=[
            validators.MinValueValidator(0)
        ]
    )
