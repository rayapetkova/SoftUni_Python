from django.urls import path

from My_Music_App.auth_users.views import profile_details_view, DeleteProfileView

urlpatterns = [
    path('details/', profile_details_view, name='profile-details'),
    path('delete/', DeleteProfileView.as_view(), name='profile-delete')
]