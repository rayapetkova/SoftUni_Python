from django.shortcuts import render
from django.urls import reverse_lazy
from django.views.generic import DeleteView

from My_Music_App.auth_users.models import Profile


def profile_details_view(request):
    profile = Profile.objects.all().first()
    albums_count = profile.albums.count()

    context = {
        'profile': profile,
        'albums_count': albums_count
    }

    return render(request, 'profile-details.html', context=context)


class DeleteProfileView(DeleteView):
    model = Profile
    template_name = 'profile-delete.html'
    success_url = reverse_lazy('home-page')

    def get_object(self, queryset=None):
        return Profile.objects.all().first()