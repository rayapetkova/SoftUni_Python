from django.shortcuts import render, redirect
from My_Music_App.auth_users.models import Profile
from My_Music_App.home.forms import ProfileForm


def home_page(request):
    context = {}

    if not Profile.objects.all():
        form = ProfileForm(request.POST or None)
        if request.method == 'POST':
            if form.is_valid():
                form.save()

                return redirect('home-page')

        context['form'] = form
        return render(request, 'home-no-profile.html', context=context)
    else:
        person = Profile.objects.all().first()
        person_albums = person.albums

        context = {
            'person_albums': person_albums.all()
        }

        return render(request, 'home-with-profile.html', context=context)
