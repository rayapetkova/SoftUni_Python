from django.apps import AppConfig


class AlbumsManagementConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'My_Music_App.albums_management'
