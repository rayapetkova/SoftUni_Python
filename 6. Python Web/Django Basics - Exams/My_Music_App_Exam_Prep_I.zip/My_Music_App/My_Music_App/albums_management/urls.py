from django.urls import path

from My_Music_App.albums_management.views import CreateAlbumView, DetailsAlbumView, UpdateAlbumView, delete_album_view

urlpatterns = [
    path('add/', CreateAlbumView.as_view(), name='add-album'),
    path('<int:pk>/details/', DetailsAlbumView.as_view(), name='details-album'),
    path('<int:pk>/edit/', UpdateAlbumView.as_view(), name='edit-album'),
    path('<int:pk>/delete/', delete_album_view, name='delete-album')
]
