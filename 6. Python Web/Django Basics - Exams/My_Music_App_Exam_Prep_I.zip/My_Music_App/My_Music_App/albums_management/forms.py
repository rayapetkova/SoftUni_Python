from django import forms

from My_Music_App.albums_management.models import Album
from My_Music_App.auth_users.models import Profile


class AlbumCreateForm(forms.ModelForm):

    class Meta:
        model = Album
        fields = ('name', 'artist', 'genre', 'description', 'image_url', 'price')

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        self.fields['name'].widget.attrs['placeholder'] = 'Album Name'
        self.fields['artist'].widget.attrs['placeholder'] = 'Artist'
        self.fields['genre'].widget.attrs['placeholder'] = 'Genre'
        self.fields['description'].widget.attrs['placeholder'] = 'Description'
        self.fields['image_url'].widget.attrs['placeholder'] = 'Image URL'
        self.fields['price'].widget.attrs['placeholder'] = 'Price'

    def save(self, commit=True):
        album = super().save(commit=False)
        owner = Profile.objects.all().first()
        album.owner = owner

        if commit:
            album.save()

        return album


class AlbumDeleteForm(AlbumCreateForm):
    class Meta:
        model = Album
        fields = ('name', 'artist', 'genre', 'description', 'image_url', 'price')

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        self.fields['name'].widget.attrs['readonly'] = 'Album Name'
        self.fields['artist'].widget.attrs['readonly'] = 'Artist'
        self.fields['genre'].widget.attrs['readonly'] = 'Genre'
        self.fields['description'].widget.attrs['readonly'] = 'Description'
        self.fields['image_url'].widget.attrs['readonly'] = 'Image URL'
        self.fields['price'].widget.attrs['readonly'] = 'Price'
