from django import forms

from Tasty_Recipes_App.app_users.models import Profile
from Tasty_Recipes_App.recipes.models import Recipe


class RecipeBaseForm(forms.ModelForm):

    class Meta:
        model = Recipe
        exclude = ('author', )


class RecipeCreateForm(RecipeBaseForm):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        self.fields['ingredients'].widget.attrs['placeholder'] = "ingredient1, ingredient2, ..."
        self.fields['instructions'].widget.attrs['placeholder'] = "Enter detailed instructions here..."
        self.fields['image_URL'].widget.attrs['placeholder'] = "Optional image URL here..."

    def save(self, commit=True):
        recipe = super().save(commit=False)

        user = Profile.objects.all().first()
        recipe.author = user

        if commit:
            recipe.save()

        return recipe


class RecipeUpdateForm(RecipeBaseForm):
    pass


class RecipeDeleteForm(RecipeBaseForm):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        for field in self.fields:
            self.fields[field].widget.attrs['readonly'] = 'readonly'
