from django.core import validators
from django.db import models

from Tasty_Recipes_App.app_users.models import Profile


class Recipe(models.Model):
    CUISINE_TYPE_CHOICES = (
        ('French', 'French'),
        ('Chinese', 'Chinese'),
        ('Italian', 'Italian'),
        ('Balkan', 'Balkan'),
        ('Other', 'Other')
    )

    title = models.CharField(
        null=False,
        blank=False,
        unique=True,
        max_length=100,
        validators=[
            validators.MinLengthValidator(2)
        ],
        error_messages={
            'unique': "We already have a recipe with the same title!"
        }
    )

    cuisine_type = models.CharField(
        null=False,
        blank=False,
        max_length=7,
        choices=CUISINE_TYPE_CHOICES
    )

    ingredients = models.TextField(
        null=False,
        blank=False,
        help_text="Ingredients must be separated by a comma and space."
    )

    instructions = models.TextField(
        null=False,
        blank=False
    )

    cooking_time = models.PositiveIntegerField(
        null=False,
        blank=False,
        validators=[
            validators.MinValueValidator(1)
        ],
        help_text="Provide the cooking time in minutes."
    )

    image_URL = models.URLField(
        null=True,
        blank=True
    )

    author = models.ForeignKey(
        to=Profile,
        on_delete=models.CASCADE,
        related_name='recipes'
    )
