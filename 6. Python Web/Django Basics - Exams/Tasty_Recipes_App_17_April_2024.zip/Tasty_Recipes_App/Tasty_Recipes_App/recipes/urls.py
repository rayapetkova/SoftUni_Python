from django.urls import path

from Tasty_Recipes_App.recipes.views import CreateRecipeView, catalogue_view, DetailsRecipeView, UpdateRecipeView, \
    delete_recipe_view

urlpatterns = [
    path('create/', CreateRecipeView.as_view(), name='create-recipe'),
    path('catalogue/', catalogue_view, name='catalogue'),
    path('<int:recipe_id>/details/', DetailsRecipeView.as_view(), name='details-recipe'),
    path('<int:recipe_id>/edit/', UpdateRecipeView.as_view(), name='edit-recipe'),
    path('<int:recipe_id>/delete/', delete_recipe_view, name='delete-recipe')
]
