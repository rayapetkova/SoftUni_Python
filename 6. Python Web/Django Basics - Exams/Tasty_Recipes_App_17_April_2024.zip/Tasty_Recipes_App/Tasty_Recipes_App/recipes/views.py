from django.shortcuts import render, redirect
from django.urls import reverse_lazy
from django.views.generic import CreateView, DetailView, UpdateView, DeleteView

from Tasty_Recipes_App.app_users.models import Profile
from Tasty_Recipes_App.recipes.forms import RecipeCreateForm, RecipeUpdateForm, RecipeDeleteForm
from Tasty_Recipes_App.recipes.models import Recipe


class CreateRecipeView(CreateView):
    model = Recipe
    form_class = RecipeCreateForm
    template_name = 'create-recipe.html'
    success_url = reverse_lazy('catalogue')

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)

        user = Profile.objects.all().first()
        context['user'] = user

        return context


class DetailsRecipeView(DetailView):
    model = Recipe
    pk_url_kwarg = 'recipe_id'
    template_name = 'details-recipe.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)

        recipe = self.get_object()
        recipe_ingredients = recipe.ingredients.split(', ')

        user = Profile.objects.all().first()
        context['user'] = user
        context['recipe_ingredients'] = recipe_ingredients

        return context


class UpdateRecipeView(UpdateView):
    model = Recipe
    pk_url_kwarg = 'recipe_id'
    form_class = RecipeUpdateForm
    template_name = 'edit-recipe.html'
    success_url = reverse_lazy('catalogue')

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)

        user = Profile.objects.all().first()
        context['user'] = user

        return context


def delete_recipe_view(request, recipe_id):
    user = Profile.objects.all().first()

    recipe = Recipe.objects.filter(id=recipe_id).first()
    form = RecipeDeleteForm(instance=recipe)

    if request.method == 'POST':
        recipe.delete()
        return redirect('catalogue')

    context = {
        'user': user,
        'form': form
    }

    return render(request, 'delete-recipe.html', context=context)


def catalogue_view(request):
    recipes = Recipe.objects.all()
    user = Profile.objects.all().first()

    context = {
        'recipes': recipes,
        'user': user
    }

    return render(request, 'catalogue.html', context=context)
