from django.shortcuts import render

from Tasty_Recipes_App.app_users.models import Profile


def home_page_view(request):
    user = Profile.objects.all().first()

    context = {
        'user': user
    }

    return render(request, 'home-page.html', context=context)
