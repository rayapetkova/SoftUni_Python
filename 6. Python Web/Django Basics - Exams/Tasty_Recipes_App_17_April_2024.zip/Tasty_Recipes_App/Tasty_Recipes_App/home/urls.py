from django.urls import path

from Tasty_Recipes_App.home.views import home_page_view

urlpatterns = [
    path('', home_page_view, name='home-page')
]
