from django.core import validators
from django.core.exceptions import ValidationError
from django.db import models


def first_and_last_names_validator(value):
    if not value[0].isupper():
        raise ValidationError("Name must start with a capital letter!")

    return value


class Profile(models.Model):
    nickname = models.CharField(
        null=False,
        blank=False,
        unique=True,
        max_length=20,
        validators=[
            validators.MinLengthValidator(2, "Nickname must be at least 2 chars long!")
        ]
    )

    first_name = models.CharField(
        null=False,
        blank=False,
        max_length=30,
        validators=[
            first_and_last_names_validator
        ]
    )

    last_name = models.CharField(
        null=False,
        blank=False,
        max_length=30,
        validators=[
            first_and_last_names_validator
        ]
    )

    chef = models.BooleanField(
        null=False,
        blank=False,
        default=False
    )

    bio = models.TextField(
        null=True,
        blank=True
    )
