from django import forms

from Tasty_Recipes_App.app_users.models import Profile


class ProfileBaseForm(forms.ModelForm):

    class Meta:
        model = Profile
        fields = '__all__'


class ProfileCreateForm(ProfileBaseForm):

    class Meta:
        model = Profile
        fields = ('nickname', 'first_name', 'last_name', 'chef')


class ProfileUpdateForm(ProfileBaseForm):
    pass
