from django.shortcuts import render
from django.urls import reverse_lazy
from django.views.generic import CreateView, DetailView, UpdateView, DeleteView

from Tasty_Recipes_App.app_users.forms import ProfileCreateForm, ProfileUpdateForm
from Tasty_Recipes_App.app_users.models import Profile


class CreateProfileView(CreateView):
    model = Profile
    form_class = ProfileCreateForm
    template_name = 'create-profile.html'
    success_url = reverse_lazy('catalogue')

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)

        user = Profile.objects.all().first()
        context['user'] = user

        return context


class DetailsProfileView(DetailView):
    model = Profile
    template_name = 'details-profile.html'

    def get_object(self, queryset=None):
        user = Profile.objects.all().first()
        return user


class UpdateProfileView(UpdateView):
    model = Profile
    form_class = ProfileUpdateForm
    template_name = 'edit-profile.html'
    success_url = reverse_lazy('details-profile')

    def get_object(self, queryset=None):
        user = Profile.objects.all().first()
        return user


class DeleteProfileView(DeleteView):
    model = Profile
    template_name = 'delete-profile.html'
    success_url = reverse_lazy('home-page')

    def get_object(self, queryset=None):
        user = Profile.objects.all().first()
        return user
