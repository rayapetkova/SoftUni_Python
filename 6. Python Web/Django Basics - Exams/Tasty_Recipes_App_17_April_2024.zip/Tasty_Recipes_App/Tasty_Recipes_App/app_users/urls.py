from django.urls import path

from Tasty_Recipes_App.app_users.views import CreateProfileView, DetailsProfileView, UpdateProfileView, \
    DeleteProfileView

urlpatterns = [
    path('create/', CreateProfileView.as_view(), name='create-profile'),
    path('details/', DetailsProfileView.as_view(), name='details-profile'),
    path('edit/', UpdateProfileView.as_view(), name='edit-profile'),
    path('delete/', DeleteProfileView.as_view(), name='delete-profile')
]
