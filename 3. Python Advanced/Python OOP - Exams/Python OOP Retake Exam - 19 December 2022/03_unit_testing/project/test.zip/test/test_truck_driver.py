from project.truck_driver import TruckDriver
from unittest import TestCase, main


class TruckDriverTests(TestCase):
    def setUp(self) -> None:
        self.driver = TruckDriver("TestName", 4.0)

    def test_initialization(self):
        self.assertEqual("TestName", self.driver.name)
        self.assertEqual(4.0, self.driver.money_per_mile)
        self.assertEqual({}, self.driver.available_cargos)
        self.assertEqual(0, self.driver.earned_money)
        self.assertEqual(0, self.driver.miles)

    def test_earned_money_method_raise_exception_value_is_less_than_zero(self):
        with self.assertRaises(ValueError) as ve:
            self.driver.earned_money = -20

        self.assertEqual(f"TestName went bankrupt.", str(ve.exception))

    def test_add_cargo_offer_raise_exception_cargo_location_already_in_available_cargos(self):
        self.driver.available_cargos = {"First": 20}

        with self.assertRaises(Exception) as ex:
            self.driver.add_cargo_offer("First", 40)

        self.assertEqual(f"Cargo offer is already added.", str(ex.exception))

    def test_add_cargo_offer_method(self):
        result = self.driver.add_cargo_offer("First", 40)

        self.assertEqual({"First": 40}, self.driver.available_cargos)
        self.assertEqual(f"Cargo for 40 to First was added as an offer.", result)

    def test_drive_best_cargo_offer_catch_error_empty_dictionary(self):
        self.assertEqual(f"There are no offers available.", self.driver.drive_best_cargo_offer())

    def test_drive_best_cargo_offer(self):
        offers = (("varna", 10), ("burgas", 40))
        for location, miles in offers:
            self.driver.add_cargo_offer(location, miles)

        actual_msg = self.driver.drive_best_cargo_offer()

        self.assertEqual("Tamer is driving 40 to burgas.", actual_msg)
        self.assertEqual(48, self.driver.earned_money)
        self.assertEqual(40, self.driver.miles)

    def test_check_for_activities_method(self):
        self.driver.earned_money = 10_000

        self.driver.check_for_activities(250)
        self.assertEqual(9980, self.driver.earned_money)

        self.driver.earned_money = 10_000

        self.driver.check_for_activities(1000)
        self.assertEqual(9875, self.driver.earned_money)

        self.driver.earned_money = 10_000

        self.driver.check_for_activities(1500)
        self.assertEqual(9335, self.driver.earned_money)

        self.driver.earned_money = 100_000

        self.driver.check_for_activities(10_000)
        self.assertEqual(88250, self.driver.earned_money)

    def test_repr_method(self):
        self.assertEqual(f"TestName has 0 miles behind his back.", str(self.driver))


if __name__ == "__main__":
    main()
