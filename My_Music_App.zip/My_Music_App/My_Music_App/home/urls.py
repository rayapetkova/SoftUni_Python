from django.urls import path

from My_Music_App.home.views import home_page

urlpatterns = [
    path('', home_page, name='home-page'),
]
