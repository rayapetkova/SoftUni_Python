from django.apps import AppConfig


class AuthUsersConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'My_Music_App.auth_users'
