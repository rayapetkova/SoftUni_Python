from django.shortcuts import render, redirect
from django.urls import reverse_lazy
from django.views.generic import CreateView, DetailView, UpdateView, DeleteView

from My_Music_App.albums_management.forms import AlbumCreateForm, AlbumDeleteForm
from My_Music_App.albums_management.models import Album


class CreateAlbumView(CreateView):
    form_class = AlbumCreateForm
    template_name = 'album-add.html'
    success_url = reverse_lazy('home-page')


class DetailsAlbumView(DetailView):
    model = Album
    template_name = 'album-details.html'


class UpdateAlbumView(UpdateView):
    model = Album
    template_name = 'album-edit.html'
    fields = ('name', 'artist', 'genre', 'description', 'image_url', 'price')
    success_url = reverse_lazy('home-page')


def delete_album_view(request, pk):
    album = Album.objects.get(id=pk)

    form = AlbumDeleteForm(instance=album)
    if request.method == "POST":
        album.delete()
        return redirect('home-page')

    context = {
        'object': album,
        'form': form
    }
    return render(request, 'album-delete.html', context=context)