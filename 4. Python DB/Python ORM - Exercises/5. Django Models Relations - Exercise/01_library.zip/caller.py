import os
import django

# Set up Django
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "orm_skeleton.settings")
django.setup()

# Import your models here
from main_app.models import Author, Book

# Create queries within functions
def show_all_authors_with_their_books():
    authors = Author.objects.all()

    final_result = []
    for author in authors:
        author_books = author.book_set.all()

        if author_books:
            final_result.append(f"{author.name} has written - {', '.join(b.title for b in author_books)}!")

    return '\n'.join(final_result)


def delete_all_authors_without_books():
    authors = Author.objects.all()

    for author in authors:
        if author.book_set.all().count() == 0:
            author.delete()

