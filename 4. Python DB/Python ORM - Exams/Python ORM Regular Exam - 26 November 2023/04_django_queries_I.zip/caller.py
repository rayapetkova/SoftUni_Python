import os
import django

# Set up Django
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "orm_skeleton.settings")
django.setup()

# Import your models here
from main_app.models import Author, Article, Review
from django.db.models import Count


# Create and run your queries within functions
def get_authors(search_name=None, search_email=None):

    if search_name is None and search_email is None:
        return ""

    authors = []

    if search_name is not None and search_email is not None:
        authors = Author.objects.filter(
            full_name__icontains=search_name,
            email__icontains=search_email
        ).order_by('-full_name')

    elif search_name is not None and search_email is None:
        authors = Author.objects.filter(
            full_name__icontains=search_name
        ).order_by('-full_name')

    elif search_name is None and search_email is not None:
        authors = Author.objects.filter(
            email__icontains=search_email
        ).order_by('-full_name')

    if not authors:
        return ""

    final_result = []
    for author in authors:
        status = ""

        if author.is_banned:
            status = "Banned"
        else:
            status = "Not Banned"

        final_result.append(f"Author: {author.full_name}, email: {author.email}, status: {status}")

    return '\n'.join(final_result)


def get_top_publisher():
    top_author = Author.objects.annotate(total_articles=Count('author_articles'))\
        .filter(total_articles__gt=0)\
        .order_by('-total_articles', 'email')\
        .first()

    if not top_author:
        return ""

    return f"Top Author: {top_author.full_name} with {top_author.total_articles} published articles."


def get_top_reviewer():
    author = Author.objects.annotate(total_reviews=Count('author_reviews'))\
        .filter(total_reviews__gt=0)\
        .order_by('-total_reviews', 'email').first()

    if not author:
        return ""

    return f"Top Reviewer: {author.full_name} with {author.total_reviews} published reviews."