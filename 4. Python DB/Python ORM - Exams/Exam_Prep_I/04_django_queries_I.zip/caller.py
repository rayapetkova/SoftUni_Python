import os
import django
from _decimal import Decimal
from django.db.models import Count, Avg, Max, Sum, F

# Set up Django
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "orm_skeleton.settings")
django.setup()

# Import your models here
from main_app.models import Director, Actor, Movie


# Create and run your queries within functions


def get_directors(search_name=None, search_nationality=None):
    if search_name is None and search_nationality is None:
        return ''

    if search_name and search_nationality:
        directors = Director.objects.filter(
            full_name__icontains=search_name,
            nationality__icontains=search_nationality
        ).order_by("full_name")

    elif search_name and not search_nationality:
        directors = Director.objects.filter(
            full_name__icontains=search_name
        ).order_by("full_name")

    elif not search_name and search_nationality:
        directors = Director.objects.filter(
            nationality__icontains=search_nationality
        ).order_by("full_name")

    if not directors:
        return ""

    final_result = []
    for director in directors:
        final_result.append(f"Director: {director.full_name}, nationality: {director.nationality}, experience: {director.years_of_experience}")

    return '\n'.join(final_result)


def get_top_director():
    top_director = Director.objects.annotate(total_movies=Count('director_movies')).order_by('-total_movies', 'full_name').first()

    if not top_director:
        return ""

    return f"Top Director: {top_director.full_name}, movies: {top_director.total_movies}."


def get_top_actor():
    top_actor = Actor.objects.annotate(
        total_starring_movies=Count('actor_movies'),
        average_rating_movies=Avg('actor_movies__rating'))\
        .order_by('-total_starring_movies', 'full_name')\
        .first()

    if not top_actor or not top_actor.total_starring_movies:
        return ""

    top_actor_movies = ', '.join([m.title for m in top_actor.actor_movies.all() if m])

    return f"Top Actor: {top_actor.full_name}, starring in movies: {top_actor_movies}, movies average rating: {top_actor.average_rating_movies:.1f}"





















# DATA CREATION
# director1 = Director.objects.get(
#     full_name='First Director',
#     birth_date='1956-01-01',
#     nationality='Bulgarian',
#     years_of_experience=10
# )
#
# director2 = Director.objects.get(
#     full_name='Second Director',
#     birth_date='1960-01-01',
#     nationality='Romanian',
#     years_of_experience=5
# )
#
# director3 = Director.objects.get(
#     full_name='Third Director',
#     birth_date='1968-01-01',
#     nationality='Turkish',
#     years_of_experience=4
# )
#
# director4 = Director.objects.get(
#     full_name='Forth Director',
#     birth_date='1970-01-01',
#     nationality='French',
#     years_of_experience=6
# )
#
#
# actor1 = Actor.objects.get(
#     full_name='First Actor',
#     birth_date='1944-01-01',
#     nationality='Russian',
#     is_awarded=False,
# )
#
# actor2 = Actor.objects.get(
#     full_name='Second Actor',
#     birth_date='1935-01-01',
#     nationality='Bulgarian',
#     is_awarded=True,
# )
#
# actor3 = Actor.objects.get(
#     full_name='Third Actor',
#     birth_date='1968-01-01',
#     nationality='Romanian',
#     is_awarded=False,
# )
#
# actor4 = Actor.objects.get(
#     full_name='Forth Actor',
#     birth_date='1960-01-01',
#     nationality='Lithuanian',
#     is_awarded=True,
# )
#
#
# movie1 = Movie.objects.get(
#     title='First Movie',
#     release_date='2000-01-01',
#     storyline='First Storyline',
#     genre='Action',
#     rating=10,
#     is_classic=True,
#     is_awarded=True,
#     director=director1,
#     starring_actor=actor1,
# )
#
# # movie1.actors.add(actor1, actor2, actor3)
#
# movie2 = Movie.objects.get(
#     title='Second Movie',
#     release_date='2002-01-01',
#     storyline='Second Storyline',
#     genre='Comedy',
#     rating=6,
#     is_classic=False,
#     is_awarded=True,
#     director=director2,
#     starring_actor=actor2,
# )
#
# # movie2.actors.add(actor2, actor3, actor4)
#
# movie3 = Movie.objects.get(
#     title='Third Movie',
#     release_date='2005-01-01',
#     storyline='Third Storyline',
#     genre='Drama',
#     rating=8,
#     is_classic=True,
#     is_awarded=False,
#     director=director3,
#     starring_actor=actor3,
# )
#
# # movie3.actors.add(actor3, actor4, actor1)
#
# movie4 = Movie.objects.get(
#     title='Forth Movie',
#     release_date='2007-01-01',
#     storyline='Forth Storyline',
#     genre='Other',
#     rating=4,
#     is_classic=False,
#     is_awarded=False,
#     director=director4,
#     starring_actor=actor4,
# )
#
# # movie4.actors.add(actor4, actor1, actor2)