import os
import django

# Set up Django
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "orm_skeleton.settings")
django.setup()

# Import your models here
from main_app.models import Director, Actor, Movie

# Create and run your queries within functions
# director = Director.objects.get(
#     full_name='First Director',
# )
#
# actor = Actor.objects.get(
#     full_name="First Actor",
# )
#
# movie = Movie.objects.get(
#     title="First Movie",
#     release_date='1991-01-01',
#     director=director,
#     starring_actor=actor
# )
#
# print(Director.objects.get_directors_by_movies_count())