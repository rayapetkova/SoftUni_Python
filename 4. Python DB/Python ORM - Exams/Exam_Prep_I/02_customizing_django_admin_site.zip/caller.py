import os
import django
from django.db.models import Count, Avg, Max, Sum

# Set up Django
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "orm_skeleton.settings")
django.setup()

# Import your models here
from main_app.models import Director, Actor, Movie

# Create and run your queries within functions
# director = Director.objects.get(
#     full_name='First Director',
# )
#
# actor = Actor.objects.get(
#     full_name="First Actor",
# )
#
# movie = Movie.objects.get(
#     title="First Movie",
#     release_date='1991-01-01',
#     director=director,
#     starring_actor=actor
# )

# Movie.objects.create(
#     title="Second Movie",
#     release_date='1992-01-01',
#     director=director,
#     starring_actor=actor
# )

def get_directors(search_name=None, search_nationality=None):

    final_result = ""

    if search_name is not None and search_nationality is not None:
        final_result = Director.objects.filter(
            full_name__icontains=search_name,
            nationality__icontains=search_nationality
        ).order_by('full_name')

    elif search_name is None and search_nationality is None:
        final_result = ""

    elif search_name is None:
        final_result = Director.objects.filter(
            nationality__icontains=search_nationality
        ).order_by('full_name')

    elif search_nationality is None:
        final_result = Director.objects.filter(
            full_name__icontains=search_name
        ).order_by('full_name')

    if final_result:
        return '\n'.join([f"Director: {d.full_name}, nationality: {d.nationality}, experience: {d.years_of_experience}" for d in final_result])

    return final_result


def get_top_director():
    top_director = Director.objects.get_directors_by_movies_count().first()
    return f"Top Director: {top_director.full_name}, movies: {top_director.director_movies.count()}."


def get_top_actor():
    top_actor = Actor.objects.annotate(total_movies=Count('actor_movies')).order_by('-total_movies', 'full_name').first()

    average_ratings = Actor.objects.aggregate(average_ratings=Avg('actor_movies__rating'))["average_ratings"]

    if not top_actor or not top_actor.actor_movies.all():
        return ""

    a_movies = ', '.join(m.title for m in top_actor.actor_movies.all())
    return f"Top Actor: {top_actor.full_name}, starring in movies: {a_movies}, " \
           f"movies average rating: {float(average_ratings):.1f}"
